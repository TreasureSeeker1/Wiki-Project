window.onload = () => {
  document.getElementById("mydiv").innerHTML = "Hello world! 😀"
};
